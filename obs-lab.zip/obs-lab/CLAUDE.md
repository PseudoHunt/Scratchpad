# Obs-Lab: rules for every agent in this repo

This repo is an observation-first research loop for **KV-cache efficiency in LLMs**.
The goal is research ideas that come from *measured surprises*, not from theory alone.

## The loop

```
Prober -> Surprise finder -> Novelty checker -> Idea maker -> Killer -> [HUMAN GATE] -> Pilot runner -> Post-mortem
   ^                                                                                                     |
   +--------------------------- new probes requested / failure patterns -------------------------------+
```

Slash commands: `/observe`, `/ideate`, `/pilot <IDEA-ID>`, `/postmortem <IDEA-ID>`, `/cycle`.

## Hard rules (all agents)

1. **No idea without a surprise ID.** Every idea must cite an entry in `knowledge/surprises.md`
   and the exact number it exploits. Ideas that start from "it would be elegant if..." are rejected.
2. **A surprise must replicate.** It needs to hold on at least 2 models OR 2 domains, and the effect
   must be larger than the seed-to-seed spread. One run is a "lead", not a surprise.
3. **Always include cheap baselines.** Random eviction, sink+recent window, and SnapKV-style selection
   at the **same compression ratio**. Never compare at different budgets.
4. **Speed is a gate, not an afterthought.** Any selection/compression idea must pass a timing
   estimate (`probes/p10_selection_overhead.py`) before accuracy work starts.
5. **GPU time is expensive.** A kill test must fit in **1 GPU-hour**. Prefer CPU analysis of saved
   tensors. All scripts must be resumable (instances can be reclaimed without warning).
6. **Read `knowledge/failure_log.md` before proposing or approving anything.**
   If an idea matches a failure pattern, say which one and why this time is different.
7. **Write a prediction before every run** (expected number + what would kill the idea).
   The post-mortem compares prediction vs result. This is how we calibrate.
8. **Human gate.** Nothing that spends more than 15 GPU-minutes runs without the human approving
   the kill-test spec in `knowledge/ledger.md` (status `APPROVED`).

## Scope filters (ideas outside these are rejected by the Idea maker)

- Do NOT propose new quantization-based methods (weights or KV quantization as the core idea).
- Do NOT propose testing/verification tooling as the contribution.
- Do NOT pursue a direction whose only realistic output is a negative-results workshop paper.
- Preferred outputs: a method paper, a strong analysis paper with a usable finding, or a patent.

## Where things live

| Path | What |
|---|---|
| `probes/` | Measurement scripts. `run_all.py` runs them from `config.yaml`. |
| `observations/<run_id>/` | Raw JSON per probe/model/domain + `digest.md` (read the digest, not the JSON). |
| `knowledge/assumptions.md` | Common assumptions from the KV literature that probes test. |
| `knowledge/surprises.md` | Confirmed and candidate surprises (S-001, ...). |
| `knowledge/ideas.md` | Ideas (I-001, ...) with the surprise they come from. |
| `knowledge/ledger.md` | Kill tests, predictions, results, status. |
| `knowledge/failure_log.md` | Why past ideas died. Grows after each post-mortem. |
| `knowledge/probe_scores.md` | Which probes produced surprises/ideas that survived. |
| `pilots/<IDEA-ID>/` | Pilot code and results. |

## Style

Short, plain writing. Numbers over adjectives. State uncertainty with seeds and ranges.
