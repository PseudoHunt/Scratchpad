---
description: Run the probe suite, build a digest, and find surprises
argument-hint: [run-tag]
---

1. Use the **prober** subagent to run `probes/run_all.py` with `config.yaml` and run id
   `$(date +%Y%m%d)-$ARGUMENTS`, then build the digest.
2. Use the **surprise-finder** subagent on the new `observations/<run_id>/digest.md`.
3. If the surprise-finder asks for follow-up probes, use the **prober** to write and run them
   (only if they fit in the remaining `max_minutes`), then send results back to the surprise-finder once.
4. Report to the human in under 15 lines: run id, GPU minutes, top 3 surprises (one line each,
   with numbers and status), and any follow-up probes still pending.
