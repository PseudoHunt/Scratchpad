---
description: Full unattended cycle — observe, find surprises, ideate, write kill tests. Stops at the human gate.
argument-hint: [run-tag]
---

Run `/observe $ARGUMENTS`, then `/ideate`.
Do not run any pilot. Stop at the human gate.

Write `knowledge/CYCLE_REPORT.md` (overwrite) with:
- date, run id, GPU minutes
- new surprises (ID, status, one line)
- new ideas with killer verdicts and GPU estimates
- what you would approve first and why (2-3 lines)
- probes that produced nothing for 3+ runs (candidates to retire)
