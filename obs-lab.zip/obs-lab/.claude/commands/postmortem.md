---
description: Write a post-mortem for an idea that was tested outside /pilot
argument-hint: <IDEA-ID>
---

Use the **postmortem** subagent on idea `$ARGUMENTS`. If `pilots/$ARGUMENTS/RESULT.md` does not exist,
ask the human for the result numbers first and write them into that file.
