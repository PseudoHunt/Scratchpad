---
description: Run the kill test for an APPROVED idea, then write its post-mortem
argument-hint: <IDEA-ID>
---

1. Use the **pilot-runner** subagent on idea `$ARGUMENTS`. It must stop if the ledger status is not APPROVED.
2. When it finishes (pass or fail), use the **postmortem** subagent on `$ARGUMENTS`.
3. Report: gates passed/failed with numbers, GPU minutes, root cause, and any new failure pattern.
