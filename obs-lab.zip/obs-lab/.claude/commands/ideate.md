---
description: Turn CONFIRMED surprises into ideas and kill-test specs (no GPU use)
argument-hint: [S-XXX or empty for all new CONFIRMED surprises]
---

For each CONFIRMED surprise in `knowledge/surprises.md` that has no ideas yet (or only `$ARGUMENTS` if given):

1. **novelty-checker** on the surprise. If KNOWN-AND-EXPLOITED, stop for this surprise and note it.
2. **idea-maker** on the surprise.
3. **novelty-checker** on each new idea (closest 3 methods).
4. **killer** on each idea that is not self-rejected. Let it run Gate 0 if Gate 0 is CPU-only.

Run independent surprises in parallel.

Report to the human: a table of ideas with columns
`ID | from surprise | one-line mechanism | killer verdict | est. GPU-min`.
End with: "To run a pilot, set the ledger status to APPROVED and run /pilot <ID>."
