# Probe scores and calibration

Updated by the post-mortem agent.

## Probe yield
| Probe | Runs | Surprises (LEAD) | Surprises (CONFIRMED) | Ideas past Gate 1 | Notes |
|---|---|---|---|---|---|
| p01_sink_recent_coverage | 0 | 0 | 0 | 0 | |
| p02_importance_persistence | 0 | 0 | 0 | 0 | |
| p03_key_norm_vs_attention | 0 | 0 | 0 | 0 | |
| p04_kv_rank_and_rope_energy | 0 | 0 | 0 | 0 | |
| p05_cross_layer_agreement | 0 | 0 | 0 | 0 | |
| p06_head_roles | 0 | 0 | 0 | 0 | |
| p07_value_norm_effect | 0 | 0 | 0 | 0 | |
| p08_eviction_headroom | 0 | 0 | 0 | 0 | |
| p09_decode_drift | 0 | 0 | 0 | 0 | |
| p10_selection_overhead | 0 | 0 | 0 | 0 | |

## Prediction calibration
| Idea | Predicted | Measured | Within range? | Direction of error |
|---|---|---|---|---|
