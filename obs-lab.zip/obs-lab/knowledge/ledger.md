# Ledger

Kill tests, predictions, results. Written by the killer, pilot-runner and post-mortem agents.

**Human gate:** change `Status: PROPOSED` to `Status: APPROVED` for the ideas you want to run, then `/pilot <ID>`.

Statuses: PROPOSED -> APPROVED -> PASSED-G<n> / KILLED-G<n> -> POSTMORTEM-DONE

<!-- kill tests go here -->
