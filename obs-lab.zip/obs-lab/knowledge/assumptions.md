# Assumptions the KV-cache literature relies on

Each probe tests one or more of these. The surprise-finder compares measurements to this list.
Sources are given as the method family that relies on the belief; check exact claims in the papers before citing.

| ID | Assumption | Relied on by | Probe |
|---|---|---|---|
| A1 | Most attention mass goes to a few initial "sink" tokens plus a recent window. | StreamingLLM-style window+sink caches | p01 |
| A2 | Tokens that received high attention in the past keep receiving it later ("heavy hitters" persist). | H2O, TOVA, accumulated-score eviction | p02 |
| A3 | Key L2 norm predicts how much attention a token gets (low norm -> high attention). | Norm-based eviction (e.g. Devoto et al. 2024) | p03 |
| A4 | Keys are low-rank, and more so before RoPE than after. | Loki, SVD/PCA key compression, low-rank K caches | p04 |
| A5 | Key energy sits in a subset of RoPE frequency pairs. | RoPE-aware compression, frequency truncation | p04 |
| A6 | Token importance is similar across adjacent layers, so selections can be shared. | Cross-layer sharing, layer-wise budget methods (PyramidKV-style) | p05 |
| A7 | Heads have stable roles (retrieval vs local/streaming) independent of input. | DuoAttention-style head typing, per-head budgets | p06 |
| A8 | Attention score alone is a good importance signal; value norm adds little. | Most score-based eviction (challenged by value-aware work, e.g. VATP) | p07 |
| A9 | A smart selector has large headroom over random/recency at practical budgets. | Implicitly, every new eviction paper | p08 |
| A10 | The last prompt window predicts what decode will need. | SnapKV-style observation-window selection | p09 |
| A11 | Importance computed at prefill stays valid during long decode. | One-shot prefill compression | p09 |
| A12 | Selection/indexing cost is small compared with the attention it saves. | Query-aware retrieval (Quest, Loki, index-based methods) | p10 |

## Cross-cutting checks (apply to every probe)
- Does the result change with **domain** (prose vs math reasoning vs code)?
- Does it change with **model family** (Qwen vs Llama) or **size**?
- Does it change with **context length** or **layer depth**?
- Is it the same for **every head**, or driven by a few?

Prober: add a row whenever you add a probe.
