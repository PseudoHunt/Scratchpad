# Failure log

Why past ideas died, and the early check that would have caught each one.
Seeded from earlier KV-cache, RoPE-compression and BoA/PTQ projects. The post-mortem agent adds to this.

---

### F1 — The gap the method fixes was tiny
- **Pattern:** A principled correction to an approximation, but the approximation error was already negligible.
- **Example:** EK-FAC correction for BoA attention: the Kronecker/pooling gap for q/k was <= 0.5%. The objective
  simplifications (causal mask, softmax weighting) mattered 100-1000x more than the factorization.
- **Early check:** Measure the size of the gap first, on real tensors, against the other error sources. If it is not
  the biggest term, stop.

### F2 — Cheap baselines tie the fancy method
- **Pattern:** A clever selection rule does not beat random or recency when the budget is moderate.
- **Example:** NeymanKV v1 lost to prompt-protected random eviction on MATH500. On reasoning traces at B=256,
  random ~= full ~= v2. Stratified coverage won only on RULER counting tasks.
- **Early check:** Run probe p08 (eviction headroom). If oracle - random is small at the target budget, there is no
  room for any method. Find the budget/domain where headroom is large first.

### F3 — Better quality, no speedup
- **Pattern:** Selection is accurate, but its own cost eats the saving.
- **Example:** CrossCov-U had good index quality but inherited Loki's runtime, so no speedup.
- **Early check:** Probe p10 / Gate 1: time the selection step vs the attention it saves at the target length,
  on the target hardware, before any accuracy work.

### F4 — One seed, one corpus
- **Pattern:** An effect seen on one seed or one dataset disappears on the next.
- **Example:** BoA long-context Lext effect (seed 0, wikitext 32k) did not replicate on seed 1; the effect was the size
  of the seed spread (~0.03).
- **Early check:** Report seed spread next to every effect. Require effect > 2x spread on >= 2 seeds before believing.

### F5 — A recent paper does it better
- **Pattern:** Strong prior work appears and beats the method on its main metric.
- **Example:** SAKI (arXiv 2608.03228) beat CrossCov-U on index quality; the attention-weighted SAKI extension also failed.
- **Early check:** Novelty check on the last 3-6 months before building, and run the closest recent method as a baseline in Gate 2.

### F6 — Structured version loses to unstructured
- **Pattern:** Imposing structure (per-pair, per-head, per-frequency) costs much more error than expected.
- **Example:** Per-RoPE-frequency-pair cross-head key factorization had ~4-5x the error of plain low-rank at the
  same rank; content directions straddle RoPE pairs.
- **Early check:** Compare structured vs unstructured at matched rank/budget on saved tensors (CPU) first.

### F7 — Comparison at different budgets
- **Pattern:** A result looks good because it uses more memory than the baseline.
- **Example:** Range-split R32 looked slightly better than AW truncation+window, but at 1.8x K ratio vs AW's 4.3x.
- **Early check:** Every table row states its compression ratio. Only compare equal ratios (or plot a curve).

### F8 — The metric is dominated by a part you cannot change
- **Pattern:** Optimizing a metric whose value is mostly an invisible/constant component.
- **Example:** BoA's q/k row metric on Qwen was ~96% projection bias, which the softmax cannot see.
- **Early check:** Decompose the target metric into parts and check what fraction is actually controllable.

### F9 — Hybrid of two weak parts
- **Pattern:** Combining two components that each failed or tied baselines does not create a win.
- **Example:** Expected-Attention scorer + stratified tail (after NeymanKV/AgeKV nulls) failed.
- **Early check:** Each component must win alone somewhere before combining.

### F10 — Exactness gate on an approach that needs training
- **Pattern:** A training-free exactness test kills an idea whose real version would be trained (or the reverse).
- **Example:** Pair-structured LittleBit extension was closed on a training-free test, then reopened because QAT
  could absorb the init cost.
- **Early check:** Decide upfront whether the final method is training-free or trained, and gate it the same way.
