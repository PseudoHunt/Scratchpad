# Surprises

Written by the surprise-finder. Format and rules: `.claude/agents/surprise-finder.md`.
Only CONFIRMED surprises go to the idea-maker.

<!-- S-001 goes here -->
