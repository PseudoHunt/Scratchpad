# Ideas

Written by the idea-maker. Every idea cites a CONFIRMED surprise. Format: `.claude/agents/idea-maker.md`.

<!-- I-001 goes here -->
