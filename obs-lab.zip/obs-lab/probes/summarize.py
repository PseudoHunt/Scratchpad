"""Collate raw probe JSON into one compact digest.md for the surprise-finder.

    python probes/summarize.py observations/<run_id>
"""
import json
import sys
from collections import defaultdict
from pathlib import Path


def flat(d, prefix=""):
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flat(v, key + "."))
        elif isinstance(v, (int, float, str)) or v is None:
            out[key] = v
    return out


def fmt(v):
    if isinstance(v, float):
        return f"{v:.3g}"
    return "" if v is None else str(v)


def short(m):
    return m.split("/")[-1]


def main(run_dir):
    run_dir = Path(run_dir)
    res = [json.loads(p.read_text()) for p in sorted((run_dir / "raw").glob("*.json"))]
    errs = (run_dir / "errors.jsonl").read_text().strip().splitlines() if (run_dir / "errors.jsonl").exists() else []
    by_probe = defaultdict(list)
    for r in res:
        by_probe[r["probe"]].append(r)

    L = [f"# Digest: {run_dir.name}", ""]
    models = sorted({r["model"] for r in res})
    domains = sorted({r["domain"] for r in res if r["domain"] != "_model"})
    L += [f"- Models: {', '.join(models)}", f"- Domains: {', '.join(domains)}",
          f"- Results: {len(res)} files, errors: {len(errs)}", ""]

    # ---- flags, with replication counts
    L += ["## Flags (automatic thresholds in probes/common.py)", "",
          "`reps` = how many (model, domain) results raised the same flag. "
          "Flags with reps >= 2 across different models or domains are surprise candidates.", ""]
    fl = defaultdict(list)
    for r in res:
        for f in r["flags"]:
            fl[(r["probe"], f["flag"])].append((r["model"], r["domain"], f["detail"]))
    for (probe, name), hits in sorted(fl.items(), key=lambda kv: -len(kv[1])):
        nm = len({h[0] for h in hits}); nd = len({h[1] for h in hits})
        L.append(f"- **{name}** ({probe}) reps={len(hits)} models={nm} domains={nd}")
        for m, d, det in hits[:6]:
            L.append(f"  - {short(m)} / {d}: {det}")
        if len(hits) > 6:
            L.append(f"  - ... {len(hits) - 6} more")
    L.append("")

    # ---- per-probe tables
    for probe, rs in sorted(by_probe.items()):
        L += [f"## {probe}", "", f"Assumption ({', '.join(rs[0]['assumption_ids'])}): {rs[0]['assumption']}", ""]
        if probe == "p08_eviction_headroom":
            L += ["| model | domain | budget | random | sink_recent | h2o | snapkv | oracle_static | oracle_per_q | best practical | headroom vs random |",
                  "|---|---|---|---|---|---|---|---|---|---|---|"]
            for r in rs:
                for b, s in r["summary"].items():
                    e = s["err"]
                    L.append(f"| {short(r['model'])} | {r['domain']} | {b} | {fmt(e['random'])} | {fmt(e['sink_recent'])} | "
                             f"{fmt(e['h2o_accum'])} | {fmt(e['snapkv'])} | {fmt(e['oracle_static'])} | "
                             f"{fmt(e['oracle_per_query'])} | {s['best_practical']} | {fmt(s['headroom_vs_random'])} |")
        else:
            rows = [(r, flat(r["summary"])) for r in rs]
            cols = sorted({k for _, f in rows for k in f})[:14]
            L += ["| model | domain | " + " | ".join(cols) + " |", "|---|---|" + "---|" * len(cols)]
            for r, f in rows:
                L.append(f"| {short(r['model'])} | {r['domain']} | " + " | ".join(fmt(f.get(c)) for c in cols) + " |")
        L.append("")
        if probe == "p06_head_roles":
            L += ["Cross-domain head-role stability (fraction of heads with the same majority role in every domain):", ""]
            for m in models:
                hr = [r["head_roles"] for r in rs if r["model"] == m]
                if len(hr) < 2:
                    continue
                same = tot = 0
                for li in range(len(hr[0])):
                    for hi in range(len(hr[0][li])):
                        tot += 1
                        same += len({h[li][hi] for h in hr}) == 1
                L.append(f"- {short(m)}: {same / tot:.2f} ({len(hr)} domains)")
            L.append("")
        notes = {r["notes"] for r in rs}
        L += [f"_Notes: {' | '.join(notes)}_", ""]

    if errs:
        L += ["## Errors", ""]
        for e in errs:
            j = json.loads(e)
            L.append(f"- {j['probe']} / {short(j['model'])} / {j['domain']}: {j['error'][:200]}")
    (run_dir / "digest.md").write_text("\n".join(L))
    print(f"wrote {run_dir / 'digest.md'} ({len(L)} lines)")


if __name__ == "__main__":
    main(sys.argv[1])
