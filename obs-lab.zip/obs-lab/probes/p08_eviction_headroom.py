"""p08: How much room is there between cheap eviction baselines and an oracle?

Simulation on exact attention: the prefix [0, P) is compressible; the last E queries play
the role of decode steps and always keep their own recent tokens [P, q]. For each method we
keep B prefix tokens per head, renormalize attention over kept tokens, and measure the
relative error of the attention output  ||o - o'|| / ||o||.
"""
import torch
import torch.nn.functional as F
from common import THRESH, attn_tap, cache_kv, flag, forward, topk_mask

NAME = "p08_eviction_headroom"
ASSUMPTION_IDS = ["A9", "A2", "A10"]
ASSUMPTION = "A smart selector has large headroom over random/recency at practical budgets (implicit in eviction papers)."
PER_DOMAIN = True
METHODS = ["random", "sink_recent", "h2o_accum", "snapkv", "oracle_static", "oracle_per_query"]


def _masks(a_all, P, E, B, n_sink, obs, gen):
    """a_all: [H, L, L] attention. Returns {method: [H, P] or [H, E, P] bool mask over the prefix}."""
    H = a_all.shape[0]
    dev = a_all.device
    m = {}
    sink = torch.zeros(H, P, dtype=torch.bool, device=dev)
    sink[:, :n_sink] = True
    b = B - n_sink
    # random (sinks protected)
    r = torch.rand(H, P - n_sink, generator=gen, device="cpu").to(dev)
    m["random"] = sink.clone()
    m["random"][:, n_sink:] = topk_mask(r, b)
    # sinks + most recent prefix tokens
    m["sink_recent"] = sink.clone()
    m["sink_recent"][:, P - b:] = True
    # H2O-style accumulated attention, normalized by how many queries could see each key
    acc = a_all[:, :P, :P].sum(1) / torch.arange(P, 0, -1, device=dev).float()
    m["h2o_accum"] = sink.clone()
    m["h2o_accum"][:, n_sink:] = topk_mask(acc[:, n_sink:], b)
    # SnapKV-style: observation window = last `obs` prefix queries, avg-pooled scores
    sc = a_all[:, P - obs:P, :P].sum(1)
    sc = F.avg_pool1d(sc.unsqueeze(1), kernel_size=7, stride=1, padding=3).squeeze(1)
    m["snapkv"] = sink.clone()
    m["snapkv"][:, n_sink:] = topk_mask(sc[:, n_sink:], b)
    # oracles: best fixed set for the eval window, and best set per eval query
    ev = a_all[:, P:P + E, :P]
    m["oracle_static"] = topk_mask(ev.sum(1), B)
    m["oracle_per_query"] = topk_mask(ev, B)
    return m


def _err(a_all, V, P, E, mask):
    """Relative output error for eval queries [P, P+E) when only `mask` prefix tokens are kept."""
    ev = a_all[:, P:P + E, :]                          # [H, E, L]
    o = ev @ V                                         # [H, E, hd]
    pre, tail = ev[..., :P], ev[..., P:]
    mk = mask if mask.dim() == 3 else mask.unsqueeze(1)
    kept = pre * mk
    num = kept @ V[:, :P] + tail @ V[:, P:]
    den = kept.sum(-1, keepdim=True) + tail.sum(-1, keepdim=True)
    o2 = num / den.clamp_min(1e-12)
    return ((o - o2).norm(dim=-1) / o.norm(dim=-1).clamp_min(1e-12)).mean().item()


def run(ctx):
    info = ctx.info
    n_sink = ctx.args.get("n_sink", 4)
    E = ctx.args.get("eval_queries", 64)
    obs = ctx.args.get("obs_window", 32)
    budgets = ctx.args.get("budget_fracs", [0.05, 0.1, 0.2])
    L = ctx.samples[0].shape[1]
    P = L - E
    gen = torch.Generator().manual_seed(ctx.seed)
    errs = {bf: {m: [[] for _ in range(info.n_layers)] for m in METHODS} for bf in budgets}

    for x in ctx.samples:
        # one forward to get V for all layers, a second with the tap to process layer by layer
        out = forward(ctx.model, x, use_cache=True)
        Vs = [cache_kv(out.past_key_values, i)[1][0].float() for i in range(info.n_layers)]
        del out

        def proc(i, A):
            a_all = A[0]
            V = Vs[i].repeat_interleave(info.group, dim=0)      # [H, L, hd]
            for bf in budgets:
                B = max(n_sink + 1, int(bf * P))
                masks = _masks(a_all, P, E, B, n_sink, obs, gen)
                for mth, mk in masks.items():
                    errs[bf][mth][i].append(_err(a_all, V, P, E, mk))

        with attn_tap(ctx.model, proc):
            forward(ctx.model, x)

    summary, per_layer, flags = {}, {}, []
    for bf in budgets:
        layer_err = {m: [sum(v) / len(v) for v in errs[bf][m]] for m in METHODS}
        tot = {m: sum(v) / len(v) for m, v in layer_err.items()}
        practical = ["random", "sink_recent", "h2o_accum", "snapkv"]
        best = min(practical, key=lambda m: tot[m])
        headroom = (tot["random"] - tot["oracle_static"]) / max(tot["random"], 1e-12)
        gap = tot[best] / max(tot["oracle_static"], 1e-12)
        key = f"b{int(bf*100)}"
        summary[key] = {"err": tot, "best_practical": best, "headroom_vs_random": headroom,
                        "best_practical_over_oracle_static": gap}
        for m in METHODS:
            per_layer[f"{key}_{m}"] = layer_err[m]
        flag(flags, f"A9_small_headroom_{key}", headroom < THRESH["p08_small_headroom"],
             f"budget {bf:.0%}: oracle_static only {headroom:.0%} better than random (no room for a method here)")
        flag(flags, f"A9_big_gap_{key}", gap > THRESH["p08_big_gap"],
             f"budget {bf:.0%}: best practical ({best}) has {gap:.1f}x the oracle_static error (room for a method)")
        for m in ["h2o_accum", "snapkv"]:
            flag(flags, f"random_beats_{m}_{key}", tot["random"] < tot[m],
                 f"budget {bf:.0%}: random ({tot['random']:.3f}) beats {m} ({tot[m]:.3f})")
        worst_layer = max(range(info.n_layers), key=lambda i: layer_err[best][i])
        summary[key]["worst_layer_for_best_practical"] = worst_layer
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"prefix [0,{P}) compressible, eval queries [{P},{L}); per-query-head selection; "
                     f"budget B = frac * P incl. {n_sink} sinks; teacher-forced text"}
