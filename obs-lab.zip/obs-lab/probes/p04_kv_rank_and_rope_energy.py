"""p04: Effective rank of keys before/after RoPE and of values; key energy by RoPE frequency."""
import torch
from common import THRESH, cache_kv, effective_rank, flag, forward, kproj_tap

NAME = "p04_kv_rank_and_rope_energy"
ASSUMPTION_IDS = ["A4", "A5"]
ASSUMPTION = ("Keys are low-rank, more so before RoPE (Loki/SVD key compression); "
              "key energy sits in a subset of RoPE frequency pairs.")
PER_DOMAIN = True


def run(ctx):
    info = ctx.info
    energy = ctx.args.get("energy", 0.9)
    hd, half = info.head_dim, info.head_dim // 2
    rk = {m: [[] for _ in range(info.n_layers)] for m in ["k_pre", "k_pre_centered", "k_post", "v"]}
    lowfreq = [[] for _ in range(info.n_layers)]
    pair_energy = [[] for _ in range(info.n_layers)]
    save = ctx.args.get("save_tensors", False)
    saved = {}

    for si, x in enumerate(ctx.samples):
        store = {}
        with kproj_tap(ctx.model, store):
            out = forward(ctx.model, x, use_cache=True)
        for i in range(info.n_layers):
            kpre = store[i][0].float().view(-1, info.n_kv, hd).transpose(0, 1)   # [n_kv, L, hd]
            kpost, v = cache_kv(out.past_key_values, i)
            kpost, v = kpost[0].float(), v[0].float()
            for h in range(info.n_kv):
                rk["k_pre"][i].append(effective_rank(kpre[h], energy))
                rk["k_pre_centered"][i].append(effective_rank(kpre[h] - kpre[h].mean(0), energy))
                rk["k_post"][i].append(effective_rank(kpost[h], energy))
                rk["v"][i].append(effective_rank(v[h], energy))
            # rotate_half convention: dim j pairs with j+half; j small = high frequency
            e = kpre[..., :half] ** 2 + kpre[..., half:] ** 2               # [n_kv, L, half]
            pe = e.sum(1) / e.sum((1, 2)).unsqueeze(-1)                    # [n_kv, half]
            pair_energy[i].append(pe.mean(0).cpu())
            lowfreq[i].append(pe[:, half // 2:].sum(-1).mean().item())
            if save and si == 0:
                saved[i] = {"k_pre": kpre.half().cpu(), "k_post": kpost.half().cpu(), "v": v.half().cpu()}
    if save:
        ctx.tensor_dir.mkdir(parents=True, exist_ok=True)
        torch.save(saved, ctx.tensor_dir / f"kv_{ctx.domain.replace(':', '_').replace('/', '_')}.pt")

    mean = lambda lst: [sum(v) / len(v) for v in lst]
    per_layer = {f"eff_rank{int(energy*100)}_{m}": mean(v) for m, v in rk.items()}
    per_layer["lowfreq_half_energy"] = mean(lowfreq)
    infl = [b / max(a, 1) for a, b in zip(per_layer[f"eff_rank{int(energy*100)}_k_pre"],
                                           per_layer[f"eff_rank{int(energy*100)}_k_post"])]
    per_layer["rope_rank_inflation"] = infl
    pair = torch.stack([torch.stack(v).mean(0) for v in pair_energy]).mean(0)  # [half]
    summary = {"head_dim": hd, "rope_rank_inflation_mean": sum(infl) / len(infl),
               "lowfreq_energy_mean": sum(per_layer["lowfreq_half_energy"]) / info.n_layers,
               "k_post_rank_mean": sum(per_layer[f"eff_rank{int(energy*100)}_k_post"]) / info.n_layers,
               "v_rank_mean": sum(per_layer[f"eff_rank{int(energy*100)}_v"]) / info.n_layers,
               "pair_energy_profile_all_layers": pair}
    flags = []
    hi = [i for i, r in enumerate(infl) if r > THRESH["p04_rope_rank_inflation"]]
    flag(flags, "A4_rope_inflates_rank", len(hi) > 0, f"post/pre-RoPE rank ratio > {THRESH['p04_rope_rank_inflation']} in layers {hi}")
    lo = [i for i, r in enumerate(infl) if r < 1.0]
    flag(flags, "A4_rope_lowers_rank", len(lo) > info.n_layers // 4, f"post-RoPE rank LOWER than pre-RoPE in layers {lo}")
    flag(flags, "A5_lowfreq_concentration", summary["lowfreq_energy_mean"] > THRESH["p04_lowfreq_energy"],
         f"{summary['lowfreq_energy_mean']:.2f} of key energy is in the low-frequency half of RoPE pairs")
    vk = summary["v_rank_mean"] / max(summary["k_post_rank_mean"], 1)
    flag(flags, "values_much_higher_rank", vk > 2.0, f"value rank is {vk:.1f}x key rank (post-RoPE)")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"effective rank = #singular values for {energy:.0%} energy, per KV head, uncentered unless noted"}
