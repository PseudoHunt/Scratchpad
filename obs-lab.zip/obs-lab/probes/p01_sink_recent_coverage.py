"""p01: How much attention mass do sink tokens + a recent window cover?"""
import torch
from common import THRESH, attn_tap, flag, forward

NAME = "p01_sink_recent_coverage"
ASSUMPTION_IDS = ["A1"]
ASSUMPTION = "Most attention mass goes to a few sink tokens plus a recent window (StreamingLLM-style caches)."
PER_DOMAIN = True


def run(ctx):
    n_sink = ctx.args.get("n_sink", 4)
    windows = ctx.args.get("windows", [64, 256])
    L = ctx.samples[0].shape[1]
    qs = torch.arange(L // 2, L, device=ctx.info.device)
    # cov[w][layer] -> list over samples of per-head coverage tensors [H]
    cov = {w: [[] for _ in range(ctx.info.n_layers)] for w in windows}

    def fn(i, A):
        a = A[0][:, qs, :]                     # [H, nq, L]
        c = a.cumsum(-1)
        sink = c[..., n_sink - 1]              # [H, nq]
        for w in windows:
            start = (qs - w + 1).clamp(min=n_sink)
            idx_end = qs.view(1, -1, 1).expand(a.shape[0], -1, 1)
            idx_s = (start - 1).view(1, -1, 1).expand(a.shape[0], -1, 1)
            recent = c.gather(-1, idx_end).squeeze(-1) - c.gather(-1, idx_s).squeeze(-1)
            cov[w][i].append((sink + recent).mean(-1).cpu())  # [H]

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            forward(ctx.model, x)

    per_layer, flags, summary = {}, [], {}
    for w in windows:
        per_head = torch.stack([torch.stack(cov[w][i]).mean(0) for i in range(ctx.info.n_layers)])  # [nL, H]
        layer_mean = per_head.mean(1)
        frac_low = (per_head < THRESH["p01_head_low"]).float().mean(1)
        per_layer[f"w{w}_mean"] = layer_mean
        per_layer[f"w{w}_min_head"] = per_head.min(1).values
        per_layer[f"w{w}_frac_heads_below_{THRESH['p01_head_low']}"] = frac_low
        summary[f"w{w}_mean_all"] = layer_mean.mean().item()
        summary[f"w{w}_worst_layer"] = int(layer_mean.argmin())
        summary[f"w{w}_worst_layer_cov"] = layer_mean.min().item()
        bad = (layer_mean < THRESH["p01_low_coverage"]).nonzero().flatten().tolist()
        flag(flags, f"A1_fails_layers_w{w}", len(bad) > 0,
             f"sink({n_sink})+recent({w}) covers < {THRESH['p01_low_coverage']} of mass in layers {bad}")
        flag(flags, f"A1_nonlocal_heads_w{w}", frac_low.max().item() > 0.25,
             f"up to {frac_low.max().item():.2f} of heads in a layer have coverage < {THRESH['p01_head_low']}")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"queries = second half of each {L}-token sample; {len(ctx.samples)} samples"}
