"""p05: Do adjacent layers agree on which tokens are important?"""
import torch
from common import THRESH, attn_tap, flag, forward, jaccard_topk, spearman

NAME = "p05_cross_layer_agreement"
ASSUMPTION_IDS = ["A6"]
ASSUMPTION = "Token importance is similar across adjacent layers, so selections can be shared (cross-layer methods)."
PER_DOMAIN = True


def run(ctx):
    n_sink = ctx.args.get("n_sink", 4)
    frac = ctx.args.get("topk_frac", 0.1)
    gap = ctx.args.get("far_gap", 4)
    L = ctx.samples[0].shape[1]
    P = (3 * L) // 4
    k = max(1, int(frac * (P - n_sink)))
    nL = ctx.info.n_layers
    adj, far, rho = [[] for _ in range(nL - 1)], [[] for _ in range(max(nL - gap, 0))], [[] for _ in range(nL - 1)]
    imp = {}

    def fn(i, A):
        imp[i] = A[0][:, P:, n_sink:P].mean((0, 1))          # head-averaged importance per key [P-n_sink]

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            forward(ctx.model, x)
            for i in range(nL - 1):
                adj[i].append(jaccard_topk(imp[i], imp[i + 1], k).item())
                rho[i].append(spearman(imp[i], imp[i + 1]).item())
            for i in range(nL - gap):
                far[i].append(jaccard_topk(imp[i], imp[i + gap], k).item())

    m = lambda lst: [sum(v) / len(v) for v in lst]
    per_layer = {"jaccard_l_lplus1": m(adj), "spearman_l_lplus1": m(rho), f"jaccard_l_lplus{gap}": m(far)}
    adj_m = per_layer["jaccard_l_lplus1"]
    summary = {"adjacent_jaccard_mean": sum(adj_m) / len(adj_m),
               "adjacent_jaccard_first_quarter": sum(adj_m[: max(1, len(adj_m) // 4)]) / max(1, len(adj_m) // 4),
               "adjacent_jaccard_last_quarter": sum(adj_m[-max(1, len(adj_m) // 4):]) / max(1, len(adj_m) // 4)}
    if far:
        summary[f"jaccard_gap{gap}_mean"] = sum(per_layer[f"jaccard_l_lplus{gap}"]) / len(far)
    flags = []
    low = [i for i, v in enumerate(adj_m) if v < THRESH["p05_low_layer_agreement"]]
    flag(flags, "A6_low_agreement_layers", len(low) > 0,
         f"top-{frac:.0%} sets of layer l and l+1 overlap < {THRESH['p05_low_layer_agreement']} for l in {low}")
    flag(flags, "A6_depth_trend",
         abs(summary["adjacent_jaccard_first_quarter"] - summary["adjacent_jaccard_last_quarter"]) > 0.2,
         f"agreement changes with depth: first quarter {summary['adjacent_jaccard_first_quarter']:.2f}, "
         f"last quarter {summary['adjacent_jaccard_last_quarter']:.2f}")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": "importance = head-averaged attention from the last quarter of queries; sinks excluded"}
