"""Shared helpers for all probes.

Design notes
- Models load with eager attention so each attention module returns its softmax weights.
  A forward hook on every `self_attn` reads those weights, reduces them right away, and
  never keeps the full (H, L, L) tensor for more than one layer.
- Post-RoPE keys and values come from the KV cache. Pre-RoPE keys come from a hook on k_proj.
- "tiny-random-llama" builds a small random Llama locally (no download) for smoke tests.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import math
import os
import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import torch

# Thresholds for automatic flags. Change them BEFORE a run, never after looking at results.
THRESH = {
    "p01_low_coverage": 0.60,          # layer mean sink+recent mass below this -> A1 fails there
    "p01_head_low": 0.30,              # a head whose coverage is below this is "non-local"
    "p02_low_persistence": 0.30,       # top-k Jaccard between early and late query windows
    "p03_weak_corr": 0.20,             # |spearman(-norm, attention)| below this -> A3 weak
    "p03_strong_corr": 0.60,
    "p04_rope_rank_inflation": 1.5,    # post-RoPE / pre-RoPE effective rank
    "p04_lowfreq_energy": 0.80,        # fraction of key energy in the low-frequency half
    "p05_low_layer_agreement": 0.30,
    "p06_role_instability": 0.25,      # fraction of heads changing role across samples
    "p07_value_changes_selection": 0.70,  # top-k overlap(score, score*|v|) below this
    "p08_small_headroom": 0.20,        # (err_random - err_oracle_static)/err_random below this
    "p08_big_gap": 2.0,                # err_best_practical / err_oracle_static above this
    "p09_drift": 0.15,                 # drop in coverage from early to late decode steps
    "p09_low_coverage": 0.50,
    "p10_min_speedup": 1.2,
}

DATA_CACHE = Path(os.environ.get("OBSLAB_DATA_CACHE", "data_cache"))


# --------------------------------------------------------------------------- model loading
@dataclass
class ModelInfo:
    name: str
    n_layers: int
    n_heads: int
    n_kv: int
    head_dim: int
    device: str
    dtype: torch.dtype

    @property
    def group(self) -> int:
        return self.n_heads // self.n_kv


def _dtype(s: str) -> torch.dtype:
    return {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}[s]


def load_model(name: str, device: str = "cuda", dtype: str = "bfloat16"):
    from transformers import AutoModelForCausalLM, AutoTokenizer

    dt = _dtype(dtype)
    if name.startswith("tiny-random"):
        from transformers import LlamaConfig, LlamaForCausalLM

        cfg = LlamaConfig(
            vocab_size=1000, hidden_size=128, intermediate_size=256, num_hidden_layers=4,
            num_attention_heads=4, num_key_value_heads=2, max_position_embeddings=8192,
        )
        torch.manual_seed(0)
        model = LlamaForCausalLM._from_config(cfg, attn_implementation="eager")
        model.to(dt)
        tok = None
    else:
        tok = AutoTokenizer.from_pretrained(name)
        try:  # transformers >= 4.56 uses `dtype`
            model = AutoModelForCausalLM.from_pretrained(name, dtype=dt, attn_implementation="eager")
        except TypeError:
            model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=dt, attn_implementation="eager")
    model.to(device).eval()
    c = model.config
    n_heads = c.num_attention_heads
    head_dim = getattr(c, "head_dim", None) or c.hidden_size // n_heads
    info = ModelInfo(
        name=name, n_layers=c.num_hidden_layers, n_heads=n_heads,
        n_kv=getattr(c, "num_key_value_heads", n_heads) or n_heads,
        head_dim=head_dim, device=device, dtype=dt,
    )
    return model, tok, info


def decoder_layers(model):
    return model.model.layers


# --------------------------------------------------------------------------- data
_HF_SOURCES = {
    "prose": ("Salesforce/wikitext", "wikitext-2-raw-v1", "test", lambda r: r["text"]),
    "math": ("openai/gsm8k", "main", "test", lambda r: r["question"] + "\n" + r["answer"]),
    "code": ("openai/openai_humaneval", None, "test", lambda r: r["prompt"] + r["canonical_solution"]),
}


def _load_text(domain: str) -> str:
    if domain.startswith("local:"):
        p = Path(domain.split(":", 1)[1])
        files = sorted(p.glob("*.txt")) if p.is_dir() else [p]
        return "\n\n".join(f.read_text(errors="ignore") for f in files)
    if domain not in _HF_SOURCES:
        raise ValueError(f"unknown domain {domain}; use prose/math/code/local:<path>")
    from datasets import load_dataset

    repo, sub, split, fn = _HF_SOURCES[domain]
    ds = load_dataset(repo, sub, split=split) if sub else load_dataset(repo, split=split)
    return "\n\n".join(fn(r) for r in ds)


def get_samples(domain: str, tok, seq_len: int, n: int, seed: int, device: str) -> list[torch.Tensor]:
    """n chunks of seq_len tokens from the domain, at seeded random offsets."""
    rng = random.Random(seed)
    if tok is None:  # smoke test path
        g = torch.Generator().manual_seed(seed)
        return [torch.randint(10, 990, (1, seq_len), generator=g).to(device) for _ in range(n)]
    DATA_CACHE.mkdir(parents=True, exist_ok=True)
    key = hashlib.md5(f"{domain}|{tok.name_or_path}".encode()).hexdigest()[:12]
    cache = DATA_CACHE / f"{key}.pt"
    if cache.exists():
        ids = torch.load(cache)
    else:
        ids = torch.tensor(tok(_load_text(domain))["input_ids"], dtype=torch.long)
        torch.save(ids, cache)
    if len(ids) < seq_len + 1:
        raise ValueError(f"domain {domain} has only {len(ids)} tokens < seq_len {seq_len}")
    out = []
    for _ in range(n):
        s = rng.randrange(0, len(ids) - seq_len)
        out.append(ids[s : s + seq_len].unsqueeze(0).to(device))
    return out


# --------------------------------------------------------------------------- capture
@contextlib.contextmanager
def attn_tap(model, fn: Callable[[int, torch.Tensor], None]):
    """Call fn(layer_idx, attn_weights[B,H,Q,K] as float32) for every layer during forward."""
    handles = []

    def make(i):
        def hook(module, args, output):
            w = output[1] if isinstance(output, tuple) and len(output) > 1 else None
            if w is None:
                raise RuntimeError(
                    "Attention weights not returned. Load with attn_implementation='eager' and "
                    "transformers>=4.48."
                )
            fn(i, w.float())
        return hook

    for i, layer in enumerate(decoder_layers(model)):
        handles.append(layer.self_attn.register_forward_hook(make(i)))
    try:
        yield
    finally:
        for h in handles:
            h.remove()


@contextlib.contextmanager
def kproj_tap(model, store: dict):
    """Store pre-RoPE keys (k_proj output, incl. bias) per layer: store[i] = [B, L, n_kv*hd]."""
    handles = []

    def make(i):
        def hook(module, args, output):
            store[i] = output.detach()
        return hook

    for i, layer in enumerate(decoder_layers(model)):
        handles.append(layer.self_attn.k_proj.register_forward_hook(make(i)))
    try:
        yield
    finally:
        for h in handles:
            h.remove()


def cache_kv(cache, i: int):
    """Post-RoPE keys and values [B, n_kv, L, hd] for layer i, across cache API versions."""
    if hasattr(cache, "layers"):
        return cache.layers[i].keys, cache.layers[i].values
    if hasattr(cache, "key_cache"):
        return cache.key_cache[i], cache.value_cache[i]
    return cache[i][0], cache[i][1]


@torch.no_grad()
def forward(model, input_ids, use_cache=False):
    return model(input_ids=input_ids, use_cache=use_cache)


# --------------------------------------------------------------------------- stats
def ranks(x: torch.Tensor) -> torch.Tensor:
    return x.argsort(-1).argsort(-1).float()


def spearman(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Spearman along the last dim (no tie correction)."""
    ra, rb = ranks(a), ranks(b)
    ra = ra - ra.mean(-1, keepdim=True)
    rb = rb - rb.mean(-1, keepdim=True)
    return (ra * rb).sum(-1) / (ra.norm(dim=-1) * rb.norm(dim=-1) + 1e-12)


def topk_mask(x: torch.Tensor, k: int) -> torch.Tensor:
    idx = x.topk(k, dim=-1).indices
    m = torch.zeros_like(x, dtype=torch.bool)
    m.scatter_(-1, idx, True)
    return m


def jaccard_topk(a: torch.Tensor, b: torch.Tensor, k: int) -> torch.Tensor:
    ma, mb = topk_mask(a, k), topk_mask(b, k)
    inter = (ma & mb).sum(-1).float()
    return inter / (2 * k - inter)


def effective_rank(x: torch.Tensor, energy: float = 0.9) -> int:
    """Smallest r whose top singular values hold `energy` of the squared Frobenius norm. x: [N, d]."""
    s = torch.linalg.svdvals(x.float())
    e = (s ** 2).cumsum(0) / (s ** 2).sum()
    return int((e < energy).sum().item()) + 1


def r4(x) -> Any:
    if isinstance(x, torch.Tensor):
        x = x.tolist()
    if isinstance(x, float):
        return round(x, 4) if math.isfinite(x) else None
    if isinstance(x, list):
        return [r4(v) for v in x]
    if isinstance(x, dict):
        return {k: r4(v) for k, v in x.items()}
    return x


def flag(flags: list, name: str, cond: bool, detail: str):
    if cond:
        flags.append({"flag": name, "detail": detail})


# --------------------------------------------------------------------------- probe context / IO
@dataclass
class Ctx:
    model: Any
    tok: Any
    info: ModelInfo
    samples: list
    domain: str
    args: dict
    tensor_dir: Path
    seed: int = 0
    extra: dict = field(default_factory=dict)


def result_path(run_dir: Path, probe: str, model: str, domain: str) -> Path:
    safe = model.replace("/", "__")
    return run_dir / "raw" / f"{probe}__{safe}__{domain.replace(':', '_').replace('/', '_')}.json"


def save_result(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(r4(payload), indent=1))
    tmp.replace(path)  # atomic, so an interrupted run never leaves half a file


class Timer:
    def __init__(self):
        self.t0 = time.time()

    def minutes(self) -> float:
        return (time.time() - self.t0) / 60
