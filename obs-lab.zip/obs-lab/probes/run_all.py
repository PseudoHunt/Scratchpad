"""Run the probe suite. Resumable: finished (probe, model, domain) results are skipped.

    python probes/run_all.py --config config.yaml --run-id 20261020-first
    python probes/run_all.py --config configs/smoke.yaml --run-id smoke --only p08_eviction_headroom
"""
import argparse
import gc
import importlib
import json
import platform
import sys
import time
import traceback
from pathlib import Path

import torch
import yaml

sys.path.insert(0, str(Path(__file__).parent))
from common import Ctx, Timer, get_samples, load_model, result_path, save_result  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--only", nargs="*", help="probe names to run (default: all in config)")
    ap.add_argument("--models", nargs="*", help="override models from config")
    ap.add_argument("--out", default="observations")
    a = ap.parse_args()

    cfg = yaml.safe_load(open(a.config))
    run_dir = Path(a.out) / a.run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    timer = Timer()
    budget = cfg.get("max_minutes", 60)
    probes = a.only or cfg["probes"]
    models = a.models or cfg["models"]
    mods = {p: importlib.import_module(p) for p in probes}
    errlog = run_dir / "errors.jsonl"

    manifest = {"config": cfg, "probes": probes, "models": models, "python": platform.python_version(),
                "torch": torch.__version__, "started": time.strftime("%Y-%m-%d %H:%M:%S"),
                "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else "cpu"}
    import transformers
    manifest["transformers"] = transformers.__version__
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=1, default=str))

    for model_name in models:
        todo = [(p, d) for p in probes for d in (cfg["domains"] if mods[p].PER_DOMAIN else ["_model"])
                if not result_path(run_dir, p, model_name, d).exists()]
        if not todo:
            print(f"[skip] {model_name}: all done")
            continue
        if timer.minutes() > budget:
            print(f"[stop] time budget {budget} min reached before {model_name}")
            break
        print(f"[load] {model_name}")
        model, tok, info = load_model(model_name, cfg.get("device", "cuda"), cfg.get("dtype", "bfloat16"))
        samples_cache = {}
        for probe, domain in todo:
            if timer.minutes() > budget:
                print(f"[stop] time budget {budget} min reached; rerun the same command to resume")
                break
            mod = mods[probe]
            args = dict(cfg.get("probe_args", {}).get("_all", {}))
            args.update(cfg.get("probe_args", {}).get(probe, {}))
            if domain == "_model":
                samples = []
            else:
                if domain not in samples_cache:
                    samples_cache[domain] = get_samples(domain, tok, cfg["seq_len"], cfg["n_samples"],
                                                        cfg.get("seed", 0), info.device)
                samples = samples_cache[domain]
            ctx = Ctx(model=model, tok=tok, info=info, samples=samples, domain=domain, args=args,
                      tensor_dir=run_dir / "tensors" / model_name.replace("/", "__"), seed=cfg.get("seed", 0))
            t0 = time.time()
            try:
                with torch.no_grad():
                    out = mod.run(ctx)
                out.update({"probe": probe, "model": model_name, "domain": domain,
                            "assumption_ids": mod.ASSUMPTION_IDS, "assumption": mod.ASSUMPTION,
                            "seq_len": cfg["seq_len"], "n_samples": cfg["n_samples"], "args": args,
                            "seconds": round(time.time() - t0, 1)})
                save_result(result_path(run_dir, probe, model_name, domain), out)
                print(f"[ok]   {probe:32s} {model_name:36s} {domain:10s} {time.time()-t0:6.1f}s  flags={len(out['flags'])}")
            except Exception as e:  # keep going; one failure should not cost the GPU session
                print(f"[fail] {probe} {model_name} {domain}: {e}")
                with open(errlog, "a") as f:
                    f.write(json.dumps({"probe": probe, "model": model_name, "domain": domain,
                                        "error": repr(e), "trace": traceback.format_exc()[-2000:]}) + "\n")
            if info.device.startswith("cuda"):
                torch.cuda.empty_cache()
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    print(f"[done] {timer.minutes():.1f} min. Next: python probes/summarize.py {run_dir}")


if __name__ == "__main__":
    main()
