"""p03: Does key L2 norm predict received attention?"""
import torch
from common import THRESH, attn_tap, cache_kv, flag, forward, jaccard_topk, spearman

NAME = "p03_key_norm_vs_attention"
ASSUMPTION_IDS = ["A3"]
ASSUMPTION = "Low key L2 norm -> high attention (norm-based eviction). RoPE is a rotation, so norm is position-free."
PER_DOMAIN = True


def run(ctx):
    n_sink = ctx.args.get("n_sink", 4)
    frac = ctx.args.get("topk_frac", 0.1)
    info = ctx.info
    L = ctx.samples[0].shape[1]
    P = (3 * L) // 4
    recv = {}
    rho = [[] for _ in range(info.n_layers)]
    jac = [[] for _ in range(info.n_layers)]
    sink_norm_ratio = [[] for _ in range(info.n_layers)]

    def fn(i, A):
        # attention from the last quarter of queries to keys before P, averaged per KV group
        a = A[0][:, P:, :P].mean(1)                                  # [H, P]
        recv[i] = a.view(info.n_kv, info.group, P).mean(1)          # [n_kv, P]

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            out = forward(ctx.model, x, use_cache=True)
            for i in range(info.n_layers):
                k, _ = cache_kv(out.past_key_values, i)
                norm = k[0, :, :P].float().norm(dim=-1)              # [n_kv, P]
                r = recv[i]
                rho[i].append(spearman(-norm[:, n_sink:], r[:, n_sink:]).cpu())
                kk = max(1, int(frac * (P - n_sink)))
                jac[i].append(jaccard_topk(-norm[:, n_sink:], r[:, n_sink:], kk).cpu())
                sink_norm_ratio[i].append((norm[:, :n_sink].mean(1) / norm[:, n_sink:].mean(1)).cpu())

    rho_l = torch.stack([torch.stack(v).mean(0) for v in rho])        # [nL, n_kv]
    jac_l = torch.stack([torch.stack(v).mean(0) for v in jac])
    snr = torch.stack([torch.stack(v).mean(0) for v in sink_norm_ratio])
    per_layer = {"spearman_negnorm_vs_attn": rho_l.mean(1), "spearman_min_head": rho_l.min(1).values,
                 "spearman_max_head": rho_l.max(1).values, "topk_jaccard": jac_l.mean(1),
                 "sink_to_rest_norm_ratio": snr.mean(1)}
    summary = {"spearman_mean": rho_l.mean().item(), "topk_jaccard_mean": jac_l.mean().item(),
               "frac_heads_negative_corr": (rho_l < 0).float().mean().item()}
    flags = []
    weak = (rho_l.mean(1).abs() < THRESH["p03_weak_corr"]).nonzero().flatten().tolist()
    flag(flags, "A3_weak_layers", len(weak) > info.n_layers // 3,
         f"|spearman(-norm, attention)| < {THRESH['p03_weak_corr']} in layers {weak} (sinks excluded)")
    flag(flags, "A3_sign_flip", summary["frac_heads_negative_corr"] > 0.2,
         f"{summary['frac_heads_negative_corr']:.2f} of KV heads have the OPPOSITE sign (high norm -> high attention)")
    strong = (rho_l.mean(1) > THRESH["p03_strong_corr"]).nonzero().flatten().tolist()
    flag(flags, "A3_strong_layers", len(strong) > 0, f"norm is a strong signal in layers {strong}")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"sinks (first {n_sink}) excluded; attention from queries [{P},{L}) to keys [0,{P})"}
