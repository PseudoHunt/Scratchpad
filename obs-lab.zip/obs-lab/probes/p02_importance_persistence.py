"""p02: Do tokens that were important to earlier queries stay important for later queries?"""
import torch
from common import THRESH, attn_tap, flag, forward, jaccard_topk, spearman

NAME = "p02_importance_persistence"
ASSUMPTION_IDS = ["A2"]
ASSUMPTION = "Heavy hitters persist: past attention predicts future attention (H2O/TOVA-style eviction)."
PER_DOMAIN = True


def run(ctx):
    w = ctx.args.get("window", 64)
    frac = ctx.args.get("topk_frac", 0.1)
    n_sink = ctx.args.get("n_sink", 4)
    L = ctx.samples[0].shape[1]
    P = L // 2                       # keys [n_sink, P) are scored; sinks excluded so they don't dominate
    k = max(1, int(frac * (P - n_sink)))
    res = {m: [[] for _ in range(ctx.info.n_layers)] for m in ["jac_window", "jac_accum", "rho_window", "rho_accum"]}

    def fn(i, A):
        a = A[0]                                           # [H, L, L]
        early = a[:, P:P + w, n_sink:P].mean(1)            # queries just after P
        late = a[:, L - w:, n_sink:P].mean(1)              # queries at the end
        acc = a[:, :P, n_sink:P].sum(1)                    # H2O-style accumulation before P
        seen = torch.arange(P - n_sink, 0, -1, device=a.device).float()  # queries that could see key j
        acc = acc / seen
        res["jac_window"][i].append(jaccard_topk(early, late, k).cpu())
        res["jac_accum"][i].append(jaccard_topk(acc, late, k).cpu())
        res["rho_window"][i].append(spearman(early, late).cpu())
        res["rho_accum"][i].append(spearman(acc, late).cpu())

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            forward(ctx.model, x)

    per_layer, summary, flags = {}, {}, []
    for m, v in res.items():
        ph = torch.stack([torch.stack(v[i]).mean(0) for i in range(ctx.info.n_layers)])  # [nL, H]
        per_layer[m] = ph.mean(1)
        summary[f"{m}_mean"] = ph.mean().item()
        if m.startswith("jac"):
            per_layer[f"{m}_min_head"] = ph.min(1).values
    low = (per_layer["jac_accum"] < THRESH["p02_low_persistence"]).nonzero().flatten().tolist()
    flag(flags, "A2_weak_accumulated", len(low) > ctx.info.n_layers // 4,
         f"accumulated-score top-{frac:.0%} overlaps < {THRESH['p02_low_persistence']} with late queries in layers {low}")
    flag(flags, "A2_window_beats_accum",
         summary["jac_window_mean"] > summary["jac_accum_mean"] + 0.1,
         f"recent-window scores predict late attention better than accumulation "
         f"({summary['jac_window_mean']:.2f} vs {summary['jac_accum_mean']:.2f})")
    flag(flags, "A2_accum_beats_window",
         summary["jac_accum_mean"] > summary["jac_window_mean"] + 0.1,
         f"accumulation predicts better than a recent window "
         f"({summary['jac_accum_mean']:.2f} vs {summary['jac_window_mean']:.2f})")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"keys [{n_sink},{P}); early window queries [{P},{P+w}), late [{L-w},{L}); "
                     f"teacher-forced text, not model-generated"}
