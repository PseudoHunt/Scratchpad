"""p10: Is query-aware token selection cheaper than the attention it saves? (decode, batch 1)

Times plain PyTorch ops at the model's head sizes. Fused kernels will differ, so treat the
numbers as a first gate: if selection is not clearly cheaper here, an idea needs a kernel story.
"""
import time

import torch
import torch.nn.functional as F
from common import THRESH, flag

NAME = "p10_selection_overhead"
ASSUMPTION_IDS = ["A12"]
ASSUMPTION = "Selection/indexing cost is small compared with the attention it saves (Quest, Loki, index-based methods)."
PER_DOMAIN = False


def _time(fn, dev, reps):
    for _ in range(3):
        fn()
    if dev.startswith("cuda"):
        torch.cuda.synchronize()
        s, e = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        s.record()
        for _ in range(reps):
            fn()
        e.record()
        torch.cuda.synchronize()
        return s.elapsed_time(e) / reps * 1000          # microseconds
    t = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t) / reps * 1e6


@torch.no_grad()
def run(ctx):
    info, dev, dt = ctx.info, ctx.info.device, ctx.info.dtype
    lengths = ctx.args.get("lengths", [4096, 16384, 65536])
    ratio = ctx.args.get("keep_ratio", 0.1)
    reps = ctx.args.get("reps", 50)
    H, Hkv, hd = info.n_heads, info.n_kv, info.head_dim
    r = max(8, hd // 4)
    page = 16
    res, flags = {}, []
    for L in lengths:
        try:
            q = torch.randn(1, H, 1, hd, device=dev, dtype=dt)
            K = torch.randn(1, Hkv, L, hd, device=dev, dtype=dt)
            V = torch.randn(1, Hkv, L, hd, device=dev, dtype=dt)
            Kr = K[..., :r].contiguous()
            kmax, kmin = K.view(1, Hkv, L // page, page, hd).amax(3), K.view(1, Hkv, L // page, page, hd).amin(3)
            k = max(1, int(ratio * L))
            qg = q.view(1, Hkv, info.group, hd)
            Kx, Vx = K.repeat_interleave(info.group, 1), V.repeat_interleave(info.group, 1)
            t = {}
            t["attn_full"] = _time(lambda: F.scaled_dot_product_attention(q, Kx, Vx), dev, reps)
            t["score_full_dim"] = _time(lambda: torch.einsum("bgqd,bgld->bgql", qg, K), dev, reps)
            t["score_low_dim"] = _time(lambda: torch.einsum("bgqd,bgld->bgql", qg[..., :r], Kr), dev, reps)
            t["score_page_bound"] = _time(lambda: torch.maximum(torch.einsum("bgqd,bgld->bgql", qg, kmax),
                                                                torch.einsum("bgqd,bgld->bgql", qg, kmin)), dev, reps)
            s = torch.einsum("bgqd,bgld->bgl", qg[..., :r], Kr)
            t["topk"] = _time(lambda: s.topk(k, -1), dev, reps)
            idx = s.topk(k, -1).indices.unsqueeze(-1).expand(-1, -1, -1, hd)
            t["gather_kv"] = _time(lambda: (K.gather(2, idx), V.gather(2, idx)), dev, reps)
            Ks = K.gather(2, idx).repeat_interleave(info.group, 1)
            Vs = V.gather(2, idx).repeat_interleave(info.group, 1)
            t["attn_sparse"] = _time(lambda: F.scaled_dot_product_attention(q, Ks, Vs), dev, reps)
            sel_low = t["score_low_dim"] + t["topk"] + t["gather_kv"] + t["attn_sparse"]
            sel_full = t["score_full_dim"] + t["topk"] + t["gather_kv"] + t["attn_sparse"]
            t["speedup_lowdim_select"] = t["attn_full"] / sel_low
            t["speedup_fulldim_select"] = t["attn_full"] / sel_full
            t["selection_share_of_lowdim_path"] = (t["score_low_dim"] + t["topk"] + t["gather_kv"]) / sel_low
            res[f"L{L}"] = t
            flag(flags, f"A12_no_speedup_L{L}", t["speedup_lowdim_select"] < THRESH["p10_min_speedup"],
                 f"L={L}: low-dim ({r}) selection + sparse attention is only {t['speedup_lowdim_select']:.2f}x "
                 f"faster than full attention; selection is {t['selection_share_of_lowdim_path']:.0%} of the path")
            del q, K, V, Kr, Kx, Vx, Ks, Vs, s, idx, kmax, kmin
            if dev.startswith("cuda"):
                torch.cuda.empty_cache()
        except torch.cuda.OutOfMemoryError:
            res[f"L{L}"] = "OOM"
    gpu = torch.cuda.get_device_name() if dev.startswith("cuda") else "cpu"
    return {"summary": res, "per_layer": {}, "flags": flags,
            "notes": f"{gpu}; one layer, batch 1, decode; times in microseconds; plain PyTorch ops "
                     f"(no fused kernels); keep ratio {ratio}; low-dim r={r}; random tensors"}
