"""p09: Does a selection made at the end of prefill stay good during the model's own generation?"""
import torch
import torch.nn.functional as F
from common import THRESH, attn_tap, flag, forward, topk_mask

NAME = "p09_decode_drift"
ASSUMPTION_IDS = ["A10", "A11"]
ASSUMPTION = "The last prompt window predicts what decode will need, and stays valid over long decode (SnapKV-style one-shot compression)."
PER_DOMAIN = True


@torch.no_grad()
def run(ctx):
    info = ctx.info
    steps = ctx.args.get("decode_steps", 128)
    bf = ctx.args.get("budget_frac", 0.1)
    obs = ctx.args.get("obs_window", 32)
    n_sink = ctx.args.get("n_sink", 4)
    Lp = ctx.samples[0].shape[1]
    B = max(n_sink + 1, int(bf * Lp))
    cov_snap = [[] for _ in range(info.n_layers)]   # per sample: list over steps
    cov_oracle = [[] for _ in range(info.n_layers)]
    jac = [[] for _ in range(info.n_layers)]

    for x in ctx.samples:
        masks, cur = {}, {i: {"s": [], "o": [], "j": []} for i in range(info.n_layers)}

        def prefill_fn(i, A):
            sc = A[0][:, Lp - obs:, :].sum(1)                     # [H, Lp]
            sc = F.avg_pool1d(sc.unsqueeze(1), 7, 1, 3).squeeze(1)
            m = topk_mask(sc[:, n_sink:], B - n_sink)
            masks[i] = torch.cat([torch.ones(sc.shape[0], n_sink, dtype=torch.bool, device=sc.device), m], 1)

        def decode_fn(i, A):
            a = A[0, :, 0, :Lp]                                   # attention to prompt tokens [H, Lp]
            tot = a.sum(-1).clamp_min(1e-12)
            cur[i]["s"].append(((a * masks[i]).sum(-1) / tot).mean().item())
            cur[i]["o"].append((a.topk(B, -1).values.sum(-1) / tot).mean().item())
            om = topk_mask(a, B)
            inter = (om & masks[i]).sum(-1).float()
            cur[i]["j"].append((inter / (2 * B - inter)).mean().item())

        with attn_tap(ctx.model, prefill_fn):
            out = forward(ctx.model, x, use_cache=True)
        past = out.past_key_values
        nxt = out.logits[:, -1:].argmax(-1)
        with attn_tap(ctx.model, decode_fn):
            for _ in range(steps):
                out = ctx.model(input_ids=nxt, past_key_values=past, use_cache=True)
                past = out.past_key_values
                nxt = out.logits[:, -1:].argmax(-1)
        for i in range(info.n_layers):
            cov_snap[i].append(cur[i]["s"]); cov_oracle[i].append(cur[i]["o"]); jac[i].append(cur[i]["j"])

    w = max(1, min(16, steps // 4))
    def early_late(lst):  # lst: samples x steps
        t = torch.tensor(lst)
        return t[:, :w].mean().item(), t[:, -w:].mean().item(), t.mean(0)

    per_layer = {k: [] for k in ["snap_cov_early", "snap_cov_late", "oracle_cov_late", "jaccard_late"]}
    curve = torch.zeros(steps)
    for i in range(info.n_layers):
        e, l, c = early_late(cov_snap[i])
        per_layer["snap_cov_early"].append(e); per_layer["snap_cov_late"].append(l)
        per_layer["oracle_cov_late"].append(early_late(cov_oracle[i])[1])
        per_layer["jaccard_late"].append(early_late(jac[i])[1])
        curve += c / info.n_layers
    m = lambda k: sum(per_layer[k]) / info.n_layers
    summary = {"snap_cov_early": m("snap_cov_early"), "snap_cov_late": m("snap_cov_late"),
               "oracle_cov_late": m("oracle_cov_late"), "jaccard_late": m("jaccard_late"),
               "snap_cov_curve_every_8_steps": curve[::8]}
    flags = []
    drop = summary["snap_cov_early"] - summary["snap_cov_late"]
    flag(flags, "A11_decode_drift", drop > THRESH["p09_drift"],
         f"prefill-selected set covers {summary['snap_cov_early']:.2f} of prompt attention early in decode but "
         f"{summary['snap_cov_late']:.2f} after ~{steps} steps")
    bad = [i for i, v in enumerate(per_layer["snap_cov_late"]) if v < THRESH["p09_low_coverage"]]
    flag(flags, "A10_low_coverage_layers", len(bad) > 0, f"late-decode coverage < {THRESH['p09_low_coverage']} in layers {bad}")
    gap = summary["oracle_cov_late"] - summary["snap_cov_late"]
    flag(flags, "A10_gap_to_per_step_oracle", gap > 0.2,
         f"a per-step oracle covers {gap:.2f} more prompt mass than the prefill selection (query-aware headroom)")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": f"greedy decode {steps} steps after a {Lp}-token prompt; budget {bf:.0%} of prompt; "
                     f"coverage = share of attention-to-prompt mass on kept tokens"}
