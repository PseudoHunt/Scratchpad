"""p06: Head roles (sink / local / retrieval) and whether they are stable across inputs."""
import math

import torch
from common import THRESH, attn_tap, flag, forward

NAME = "p06_head_roles"
ASSUMPTION_IDS = ["A7"]
ASSUMPTION = "Heads have fixed roles (retrieval vs local/streaming) regardless of input (DuoAttention-style head typing)."
PER_DOMAIN = True
ROLES = ["sink", "local", "retrieval"]


def run(ctx):
    n_sink = ctx.args.get("n_sink", 4)
    local_dist = ctx.args.get("local_dist", 64)
    L = ctx.samples[0].shape[1]
    qs = torch.arange(L // 2, L, device=ctx.info.device)
    stats = {m: [[] for _ in range(ctx.info.n_layers)] for m in ["sink", "dist", "entropy", "role"]}

    def fn(i, A):
        a = A[0][:, qs, :]                                        # [H, nq, L]
        keys = torch.arange(L, device=a.device).float()
        sink = a[..., :n_sink].sum(-1).mean(-1)
        rest = a[..., n_sink:]
        rest_mass = rest.sum(-1, keepdim=True).clamp_min(1e-9)
        dist = ((qs.view(1, -1, 1).float() - keys[n_sink:]) * rest / rest_mass).sum(-1).mean(-1)
        p = a.clamp_min(1e-12)
        ent = (-(p * p.log()).sum(-1) / torch.log(qs.float() + 1)).mean(-1)   # normalized entropy
        role = torch.where(sink > 0.5, 0, torch.where(dist < local_dist, 1, 2))
        for m, v in zip(["sink", "dist", "entropy", "role"], [sink, dist, ent, role]):
            stats[m][i].append(v.cpu())

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            forward(ctx.model, x)

    roles = torch.stack([torch.stack(stats["role"][i]) for i in range(ctx.info.n_layers)])  # [nL, S, H]
    S = roles.shape[1]
    # majority role per head and instability across samples
    maj = torch.mode(roles, dim=1).values                                  # [nL, H]
    unstable = (roles != maj.unsqueeze(1)).any(1).float()                  # [nL, H]
    mean = lambda m: torch.stack([torch.stack(stats[m][i]).mean(0) for i in range(ctx.info.n_layers)])
    per_layer = {f"frac_{r}": (maj == j).float().mean(1) for j, r in enumerate(ROLES)}
    per_layer["mean_attn_distance"] = mean("dist").mean(1)
    per_layer["mean_norm_entropy"] = mean("entropy").mean(1)
    per_layer["frac_heads_role_unstable"] = unstable.mean(1)
    summary = {f"frac_{r}_heads": (maj == j).float().mean().item() for j, r in enumerate(ROLES)}
    summary["frac_heads_role_unstable_within_domain"] = unstable.mean().item() if S > 1 else None
    flags = []
    if S > 1:
        flag(flags, "A7_roles_unstable_within_domain",
             summary["frac_heads_role_unstable_within_domain"] > THRESH["p06_role_instability"],
             f"{summary['frac_heads_role_unstable_within_domain']:.2f} of heads change role between samples of the same domain")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "head_roles": maj.tolist(),   # used by summarize.py for cross-domain stability
            "notes": f"sink: >50% mass on first {n_sink}; local: mean distance < {local_dist}; else retrieval"}
