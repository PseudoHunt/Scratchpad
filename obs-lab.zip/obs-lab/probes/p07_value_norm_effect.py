"""p07: Does weighting attention by value norm change which tokens get kept?"""
import torch
from common import THRESH, attn_tap, cache_kv, flag, forward, jaccard_topk, spearman

NAME = "p07_value_norm_effect"
ASSUMPTION_IDS = ["A8"]
ASSUMPTION = "Attention score alone is enough to rank tokens; value norm adds little (challenged by value-aware eviction work)."
PER_DOMAIN = True


def run(ctx):
    n_sink = ctx.args.get("n_sink", 4)
    frac = ctx.args.get("topk_frac", 0.1)
    info = ctx.info
    L = ctx.samples[0].shape[1]
    P = (3 * L) // 4
    k = max(1, int(frac * (P - n_sink)))
    recv = {}
    jac, rho, cv = ([[] for _ in range(info.n_layers)] for _ in range(3))

    def fn(i, A):
        recv[i] = A[0][:, P:, n_sink:P].mean(1).view(info.n_kv, info.group, -1).mean(1)  # [n_kv, P-n_sink]

    with attn_tap(ctx.model, fn):
        for x in ctx.samples:
            out = forward(ctx.model, x, use_cache=True)
            for i in range(info.n_layers):
                _, v = cache_kv(out.past_key_values, i)
                vn = v[0, :, n_sink:P].float().norm(dim=-1)                 # [n_kv, P-n_sink]
                s = recv[i]
                jac[i].append(jaccard_topk(s, s * vn, k).mean().item())
                rho[i].append(spearman(s, vn).mean().item())
                cv[i].append((vn.std(-1) / vn.mean(-1)).mean().item())

    m = lambda lst: [sum(v) / len(v) for v in lst]
    per_layer = {"topk_jaccard_score_vs_score_x_vnorm": m(jac), "spearman_score_vs_vnorm": m(rho),
                 "vnorm_coeff_of_variation": m(cv)}
    j = per_layer["topk_jaccard_score_vs_score_x_vnorm"]
    summary = {"jaccard_mean": sum(j) / len(j), "vnorm_cv_mean": sum(per_layer["vnorm_coeff_of_variation"]) / len(j),
               "spearman_score_vnorm_mean": sum(per_layer["spearman_score_vs_vnorm"]) / len(j)}
    flags = []
    low = [i for i, v in enumerate(j) if v < THRESH["p07_value_changes_selection"]]
    flag(flags, "A8_value_norm_changes_selection", len(low) > 0,
         f"weighting by |v| changes the top-{frac:.0%} set (Jaccard < {THRESH['p07_value_changes_selection']}) in layers {low}")
    flag(flags, "A8_score_vnorm_anticorrelated", summary["spearman_score_vnorm_mean"] < -0.2,
         f"high-attention tokens tend to have SMALL values (spearman {summary['spearman_score_vnorm_mean']:.2f})")
    return {"summary": summary, "per_layer": per_layer, "flags": flags,
            "notes": "score = attention from last-quarter queries, averaged over each KV group; sinks excluded"}
