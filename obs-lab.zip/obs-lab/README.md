# Obs-Lab

A small multi-agent setup for Claude Code that **makes its own observations** about LLM KV caches,
finds where the data disagrees with common beliefs, and turns only those gaps into research ideas.

You stay in charge of one thing: approving which kill tests get GPU time.

## How it works

| Agent | Job | Uses GPU? |
|---|---|---|
| **prober** | Runs measurement scripts on real models and saves numbers | Yes |
| **surprise-finder** | Compares numbers with `knowledge/assumptions.md` and logs surprises | No |
| **novelty-checker** | Searches papers: is this already known or used? | No |
| **idea-maker** | Builds 1-3 methods on one confirmed surprise | No |
| **killer** | Designs the cheapest test that could kill the idea, writes a prediction | CPU only |
| **pilot-runner** | Runs the approved test, gate by gate, stops at first fail | Yes |
| **postmortem** | Records why it lived or died, updates the failure log | No |

Rules for all agents are in `CLAUDE.md`. The failure log is pre-filled with ten patterns from earlier
projects (tiny gaps, cheap baselines tying, no speedup, single-seed effects, and so on).

## Setup (on the GPU machine)

```bash
pip install -r requirements.txt
huggingface-cli login          # only needed for Llama models
python probes/run_all.py --config configs/smoke.yaml --run-id smoke   # 10-second CPU check
```

Then open the folder in Claude Code. The agents and slash commands load from `.claude/`.

## Daily use

```
/observe first        # run probes + find surprises (about 30-60 GPU-minutes on an A6000)
/ideate               # surprises -> ideas -> kill tests (no GPU)
# read knowledge/ledger.md, set Status: APPROVED on the ones worth running
/pilot I-001          # run the kill test, then the post-mortem
```

`/cycle` does `/observe` + `/ideate` in one go and writes `knowledge/CYCLE_REPORT.md`.
To run it every night on the work server, schedule a headless run, for example in cron:

```
30 1 * * *  cd ~/obs-lab && mkdir -p logs && claude -p "/cycle nightly" --permission-mode acceptEdits >> logs/cycle.log 2>&1
```

## The probes (all KV cache)

| Probe | Question it asks |
|---|---|
| p01 | Do sinks + a recent window cover most attention mass? Where not? |
| p02 | Do past heavy hitters stay heavy for later queries? |
| p03 | Does key norm predict attention? |
| p04 | Key/value rank before and after RoPE; key energy by RoPE frequency (saves K/V for CPU work) |
| p05 | Do adjacent layers agree on important tokens? |
| p06 | Are head roles (sink/local/retrieval) stable across inputs and domains? |
| p07 | Does value norm change which tokens should be kept? |
| p08 | Headroom: random vs recency vs H2O vs SnapKV vs oracle, by output error at equal budget |
| p09 | Does a prefill-time selection stay good during real greedy decoding? |
| p10 | Is selection + sparse attention actually faster than full attention at 4k-128k? |

p08 and p10 are the most important: they tell you *where* a method has room to win and whether it
can be fast. Both directly target the two most common ways earlier ideas died.

## Things to know

- **Your own data helps most.** Put reasoning traces or agent logs as `.txt` files in a folder and add
  `local:data/<folder>` to `domains` in `config.yaml`. Built-in domains are wikitext, GSM8K (many
  short problems joined together) and HumanEval.
- Most probes use teacher-forced text. Only p09 uses the model's own generations.
- p10 uses plain PyTorch ops on random tensors. It is a first gate, not a kernel benchmark.
- Thresholds for automatic flags are in `probes/common.py` (`THRESH`). Set them before a run.
- The runner is resumable. If the instance dies, rerun the same command.

## Adding another area (e.g. speculative decoding)

Ask the prober: "write probes for <area> that test these assumptions: ...". Add the assumptions to
`knowledge/assumptions.md` first. Good probes measure one belief, output small numbers, and run in
minutes.
